# 🛡️ SPECTRAL HUNTER
### Bot WhatsApp de protection de groupes contre les purgeurs

---

## 📦 Installation

```bash
# 1. Cloner / copier le projet
cd spectral-hunter

# 2. Installer les dépendances
npm install

# 3. Configurer votre numéro dans index.js
# Ligne : const OWNER_NUMBER = "22500000000";
# Remplacez par votre numéro (sans le +)

# 4. Lancer le bot
npm start
```

---

## 🔌 Connexion

Au premier démarrage, un QR Code apparaît dans le terminal.  
Scannez-le avec **WhatsApp > Appareils connectés > Connecter un appareil**.

---

## 🛡️ Fonctionnalités

| Fonctionnalité | Description |
|---|---|
| 🚫 Blacklist automatique | Bannit les attaquants après détection |
| 🐛 Détection de messages bugs | Supprime les messages malveillants |
| 💥 Détection de purge | Détecte les expulsions en masse |
| 🔒 Mode Forteresse | Verrouille le groupe en cas d'attaque |
| 📋 Logs complets | Historique dans `spectral.log` |
| 🚨 Alertes admin | Notifications WhatsApp en temps réel |

---

## 📟 Commandes

| Commande | Description |
|---|---|
| `!help` | Afficher l'aide |
| `!blacklist [numéro] [raison]` | Ajouter un numéro |
| `!unblacklist [numéro]` | Retirer un numéro |
| `!showblacklist` | Voir toute la blacklist |
| `!fortress on` | Activer le mode forteresse |
| `!fortress off` | Désactiver le mode forteresse |
| `!status` | Voir le statut du bot |

---

## ⚠️ Prérequis

- Node.js v16 ou supérieur
- Le numéro WhatsApp utilisé doit être **admin** des groupes à protéger

---

*Spectral Hunter — Développé avec whatsapp-web.js*
